package egovframework.example.sample.web;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import egovframework.example.sample.service.TestService;
import egovframework.example.sample.service.TestVO;



@Controller
public class TestController {
	@Autowired
	@Resource(name="testService")
	private TestService testService;

	
	@RequestMapping(value="testList.do")
	public String SelectTestList(TestVO vo,ModelMap model) throws Exception {
		
		
		List<?> list = testService.SelectTestList(vo);
		System.out.println(list);
		
		//데이터를 화면에 전송시킬려면 model밖에 없음
		model.addAttribute("resultList",list);

		return "testList";
	}
	
	@ResponseBody
	@RequestMapping(value = "/excelUploadAjax.do", method = RequestMethod.POST)
		public String excelUploadAjax(MultipartFile testFile, MultipartHttpServletRequest request) throws  Exception{
		
		System.out.println("업로드 진행");
		
		MultipartFile excelFile = request.getFile("excelFile");
		
		if(excelFile == null || excelFile.isEmpty()) {
			throw new RuntimeException("엑셀파일을 선택해 주세요");
		}
		
		File destFile = new File("C:\\upload\\"+excelFile.getOriginalFilename());
		
		try {
			//내가 설정한 위치에 내가 올린 파일을 만들고 
			excelFile.transferTo(destFile);
		}catch(Exception e) {
			throw new RuntimeException(e.getMessage(),e);
		}
		
		//업로드를 진행하고 다시 지우기
		testService.excelUpload(destFile);
		
		destFile.delete();
		
		//return "redirect:testList.do";
		return "redirect:testList";
		//파일전송하고 목록보여주는게 안됨 따로 url쳐야함

}
	
	    @ResponseBody
		@RequestMapping(value = "/excelDown.do")
		
		public void excelDown(@ModelAttribute TestVO testVO, HttpServletResponse response, HttpServletRequest request) throws Exception{
		
		   testService.excelDown(testVO, response);
		
		}
//	@Autowired
//	@RequestMapping(value="testListSave.do")
//	public void excelListSave(TestVO vo,HttpServletResponse response) throws Exception {
//		List<TestVO> list = testService.SelectTestList(vo);
//		Workbook workbook = new XSSFWorkbook();
//        Sheet sheet = workbook.createSheet("게시판글들");
//        int rowNo = 0;
//        Row headerRow = sheet.createRow(rowNo++);
//        headerRow.createCell(0).setCellValue("번호");
//        headerRow.createCell(1).setCellValue("이름");
//        headerRow.createCell(2).setCellValue("아이디");
//        headerRow.createCell(3).setCellValue("비밀번호");
//        for (TestVO board : list) {
//            Row row = sheet.createRow(rowNo++);
//            row.createCell(0).setCellValue(board.getNo());
//            row.createCell(1).setCellValue(board.getName());
//            row.createCell(2).setCellValue(board.getPrice());
//
//        }
// 
//        // 컨텐츠 타입과 파일명 지정
//        response.setContentType("ms-vnd/excel");
//        //response.setHeader("Content-Disposition", "attachment;filename=example.xls");
//        response.setHeader("Content-Disposition", "attachment;filename=TEST.xlsx");
//
//        // Excel File Output
//        workbook.write(response.getOutputStream());
//        
//        
//	}
//	
//	@RequestMapping(value = "/excelDown.do")
//
//	public void excelDown(HttpServletResponse response) throws Exception {
//
//
//
//	    // 게시판 목록조회
//
//	    List<TestVO> list = testService.SelectTestList();
//
//
//
//	    // 워크북 생성
//
//	    Workbook wb = new HSSFWorkbook();
//
//	    Sheet sheet = wb.createSheet("게시판");
//
//	    Row row = null;
//
//	    Cell cell = null;
//
//	    int rowNo = 0;
//
//
//
//	    // 테이블 헤더용 스타일
//
//	    CellStyle headStyle = wb.createCellStyle();
//
//	    // 가는 경계선을 가집니다.
//
//	    headStyle.setBorderTop(BorderStyle.THIN);
//
//	    headStyle.setBorderBottom(BorderStyle.THIN);
//
//	    headStyle.setBorderLeft(BorderStyle.THIN);
//
//	    headStyle.setBorderRight(BorderStyle.THIN);
//
//
//
//	    // 배경색은 노란색입니다.
//
//	    headStyle.setFillForegroundColor(HSSFColorPredefined.YELLOW.getIndex());
//
//	    headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//
//
//
//	    // 데이터는 가운데 정렬합니다.
//
//	    headStyle.setAlignment(HorizontalAlignment.CENTER);
//
//
//
//	    // 데이터용 경계 스타일 테두리만 지정
//
//	    CellStyle bodyStyle = wb.createCellStyle();
//
//	    bodyStyle.setBorderTop(BorderStyle.THIN);
//
//	    bodyStyle.setBorderBottom(BorderStyle.THIN);
//
//	    bodyStyle.setBorderLeft(BorderStyle.THIN);
//
//	    bodyStyle.setBorderRight(BorderStyle.THIN);
//
//
//
//	    // 헤더 생성
//
//	    row = sheet.createRow(rowNo++);
//
//	    cell = row.createCell(0);
//
//	    cell.setCellStyle(headStyle);
//
//	    cell.setCellValue("번호");
//
//	    cell = row.createCell(1);
//
//	    cell.setCellStyle(headStyle);
//
//	    cell.setCellValue("이름");
//
//	    cell = row.createCell(2);
//
//	    cell.setCellStyle(headStyle);
//
//	    cell.setCellValue("제목");
//
//
//
//	    // 데이터 부분 생성
//
//	    for(TestVO vo  : list) {
//
//	        row = sheet.createRow(rowNo++);
//
//	        cell = row.createCell(0);
//
//	        cell.setCellStyle(bodyStyle);
//
//	        cell.setCellValue(vo.getNo());
//
//	        cell = row.createCell(1);
//
//	        cell.setCellStyle(bodyStyle);
//
//	        cell.setCellValue(vo.getName());
//
//	        cell = row.createCell(2);
//
//	        cell.setCellStyle(bodyStyle);
//
//	        cell.setCellValue(vo.getPrice());
//
//	    }
//
//
//
//	    // 컨텐츠 타입과 파일명 지정
//
//	    response.setContentType("ms-vnd/excel");
//
//	    response.setHeader("Content-Disposition", "attachment;filename=test.xls");
//
//
//
//	    // 엑셀 출력
//
//	    wb.write(response.getOutputStream());
//
//	    wb.close();
//
//	}

//	@RequestMapping(value = "/excelDown2.do")
//	   public void excelDown2(@ModelAttribute TestVO testVO, HttpServletResponse response) throws Exception {
//		System.out.println("엑셀다운2 실행");
//		 List<?> list = testService.excelDown2(testVO);
//	     // List<TestVO> list = testService.excelDown2(vo);
//	      
//	      // 워크북 생성
//	      Workbook wb = new HSSFWorkbook();
//	      Sheet sheet = wb.createSheet("detail");
//	      Row row = null;
//	      Cell cell = null;
//	      int rowNo = 0;
//
//	      // 테이블 헤더용 스타일
//	      CellStyle headStyle = wb.createCellStyle();
//	      // 가는 경계선을 가집니다.
//	      headStyle.setBorderTop(BorderStyle.THIN);
//	      headStyle.setBorderBottom(BorderStyle.THIN);
//	      headStyle.setBorderLeft(BorderStyle.THIN);
//	      headStyle.setBorderRight(BorderStyle.THIN);
//
//	      // 배경색은 노란색입니다.
//	      headStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.YELLOW.getIndex());
//	      headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//
//	      // 데이터는 가운데 정렬합니다.
//	      headStyle.setAlignment(HorizontalAlignment.CENTER);
//
//	      // 데이터용 경계 스타일 테두리만 지정
//	      CellStyle bodyStyle = wb.createCellStyle();
//	      bodyStyle.setBorderTop(BorderStyle.THIN);
//	      bodyStyle.setBorderBottom(BorderStyle.THIN);
//	      bodyStyle.setBorderLeft(BorderStyle.THIN);
//	      bodyStyle.setBorderRight(BorderStyle.THIN);
//
//	      // 헤더 생성
//	      row = sheet.createRow(rowNo++);
//	      cell = row.createCell(0);
//	      cell.setCellStyle(headStyle);
//	      cell.setCellValue("사용내역");
//	      cell = row.createCell(1);
//	      cell.setCellStyle(headStyle);
//	      cell.setCellValue("사용일");
//	      cell = row.createCell(2);
//	      cell.setCellStyle(headStyle);
//	      cell.setCellValue("사용금액");
//
//	     
//
//	      // 데이터 부분 생성
//	      for(Object vo : list) {  
//	         row = sheet.createRow(rowNo++);
//	         cell = row.createCell(0);
//	         cell.setCellStyle(bodyStyle);
//	         cell.setCellValue(vo.no);
//	         cell.setCellValue(vo.getNo());
//	         cell = row.createCell(1);
//	         cell.setCellStyle(bodyStyle);
//	         cell.setCellValue(vo.getName());
//	         cell = row.createCell(2);
//	         cell.setCellStyle(bodyStyle);
//	         cell.setCellValue(vo.getPrice());
//
//	      }
//
//	      // 컨텐츠 타입과 파일명 지정
//	      response.setContentType("ms-vnd/excel");
//	      response.setHeader("Content-Disposition", "attachment;filename=ListSample.xls");
//
//	      // 엑셀 출력
//	      wb.write(response.getOutputStream());
//	      wb.close();
//
//	   }
}
