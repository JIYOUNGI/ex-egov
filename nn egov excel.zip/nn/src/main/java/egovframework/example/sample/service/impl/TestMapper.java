package egovframework.example.sample.service.impl;

import java.util.List;
import java.util.Map;

import egovframework.example.sample.service.TestVO;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("testMapper")
public interface TestMapper {
	//List<TestVO> list() throws Exception;

	List<TestVO> SelectTestList(TestVO vo);

	void insertExcel(Map<String, Object> paramMap);

	void insertTest(TestVO vo);
	List<TestVO> selectTestList(TestVO testVO) throws Exception;
	
//	List<TestVO> excelDown(TestVO vo);
}
