package egovframework.example.sample.service.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.sample.service.SampleVO;
import egovframework.example.sample.service.TestService;
import egovframework.example.sample.service.TestVO;
@Service("testService")
public class TestServiceImpl implements TestService {
	@Autowired
	@Resource(name = "testMapper")
	private TestMapper testDAO;
	
	@Override
	public List<?> SelectTestList(TestVO vo) throws Exception {
		// TODO Auto-generated method stub
		return testDAO.SelectTestList(vo);
	}


	@Override
	public void excelUpload(File destFile) {
		  ExcelReadOption excelReadOption = new ExcelReadOption();
	        
	        //파일경로 추가
	        excelReadOption.setFilePath(destFile.getAbsolutePath());
	        
	        //추출할 컬럼명 추가
	        excelReadOption.setOutputColumns("A", "B", "C");
	        
	        //시작행
	        excelReadOption.setStartRow(2);
	        
	        List<Map<String, String>>excelContent  = ExcelRead.read(excelReadOption);
	        
	        Map<String, Object> paramMap = new HashMap<String, Object>();
	        paramMap.put("excelContent", excelContent);
	        
	        try {
	            testDAO.insertExcel(paramMap);
	        }catch(Exception e) {
	            e.printStackTrace();
	        }
		
	}



	@Override
	public void insertExcel(TestVO vo) throws Exception {
		testDAO.insertTest(vo);
		
	}


//	@Override
//	public void excelDown(TestVO testVO, HttpServletResponse response) throws Exception {
//		// TODO Auto-generated method stub
//		
//	}


//	@Override
//	public List<?> excelDown2(TestVO vo) {
//		// TODO Auto-generated method stub
//		return testDAO.excelDown(vo);
//	}
	



	@Override
	public void excelDown(TestVO vo, HttpServletResponse response) throws Exception {
		// List<?> testList = testDAO.SelectTestList(vo);
		 List<TestVO> testList = testDAO.SelectTestList(vo);
		   try {

		      //Excel Down 시작

		      Workbook workbook = new HSSFWorkbook();

		      //시트생성

		      Sheet sheet = workbook.createSheet("관리");


		      //행, 열, 열번호

		      Row row = null;

		      Cell cell = null;

		      int rowNo = 0;

		      // 테이블 헤더용 스타일

		      CellStyle headStyle = workbook.createCellStyle();

		      // 가는 경계선을 가집니다.

		      headStyle.setBorderTop(BorderStyle.THIN);

		      headStyle.setBorderBottom(BorderStyle.THIN);

		      headStyle.setBorderLeft(BorderStyle.THIN);

		      headStyle.setBorderRight(BorderStyle.THIN);

		      // 배경색은 노란색입니다.

		      headStyle.setFillForegroundColor(HSSFColorPredefined.YELLOW.getIndex());

		      headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		      // 데이터용 경계 스타일 테두리만 지정

		      CellStyle bodyStyle = workbook.createCellStyle();

		      bodyStyle.setBorderTop(BorderStyle.THIN);

		      bodyStyle.setBorderBottom(BorderStyle.THIN);

		      bodyStyle.setBorderLeft(BorderStyle.THIN);

		      bodyStyle.setBorderRight(BorderStyle.THIN);

		      // 헤더명 설정

		      String[] headerArray = {"NO", "NAME","PRICE"};

		      row = sheet.createRow(rowNo++);

		      for(int i=0; i<headerArray.length; i++) {

		      cell = row.createCell(i);

		      cell.setCellStyle(headStyle);

		      cell.setCellValue(headerArray[i]);

		      }

		      for(TestVO excelData : testList ) {

		      row = sheet.createRow(rowNo++);

		      cell = row.createCell(0);

		      cell.setCellStyle(bodyStyle);
		      


		      cell.setCellValue(excelData.getNo());

		      cell = row.createCell(1);

		      cell.setCellStyle(bodyStyle);

		      cell.setCellValue(excelData.getName());
		      

		      cell = row.createCell(2);

		      cell.setCellStyle(bodyStyle);

		      cell.setCellValue(excelData.getPrice());

		      }

		      // 컨텐츠 타입과 파일명 지정

		      response.setContentType("ms-vnd/excel");

		      response.setHeader("Content-Disposition", "attachment; filename=" + java.net.URLEncoder.encode("***_관리.xls", "UTF8"));

		      // 엑셀 출력

		      workbook.write(response.getOutputStream());

		      workbook.close();

		      } catch (Exception e) {

		      e.printStackTrace();

		      }


		      }

}
		
	
