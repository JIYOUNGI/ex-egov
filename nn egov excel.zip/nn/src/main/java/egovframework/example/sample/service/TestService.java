package egovframework.example.sample.service;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

public interface TestService {
	
	public List<?> SelectTestList(TestVO vo) throws Exception;
	void excelUpload(File destFile);
	void insertExcel(TestVO vo) throws Exception;
    void excelDown(TestVO testVO, HttpServletResponse response) throws Exception;
   // List<?> excelDown2(TestVO vo);

}
